package com.manipal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.manipal.exception.TelephoneNotFoundException;
import com.manipal.model.Telephone;
import com.manipal.service.ITelephoneService;

@RestController
@RequestMapping("/telephones")
public class TelephoneController {
	
	@Autowired
	private ITelephoneService telephoneService;

	 @RequestMapping(value="addtelephone", method=RequestMethod.POST)
	//@PostMapping
	public String addTelephoneDetails(@RequestBody Telephone telephone) {
		System.out.println(telephone);		
		telephoneService.addOrUpdateTelephone(telephone);
		return "Number added successfully";
	}

	@PostMapping("update")
	public ResponseEntity<Telephone> updateTelephone(@RequestBody Telephone telephoneDetails) {
		Telephone telephone = telephoneService.getTelephoneById(telephoneDetails.getTelephoneId());
		if(telephone!=null)
		{
			telephone.setTelephoneNo(telephoneDetails.getTelephoneNo());
			telephone.setMobileNo(telephoneDetails.getMobileNo());
			telephoneService.addOrUpdateTelephone(telephone);
		} 
			  else { telephoneService.addOrUpdateTelephone(telephoneDetails);}
			 
		ResponseEntity responseEntity = new ResponseEntity<>(telephone, HttpStatus.OK);
		
		return responseEntity;
	}
	@GetMapping("/bytelephoneno/{telephoneNo}")
	public Telephone getTelephoneBytelephoneno(@PathVariable String telephoneNo) {	
		Telephone telephone = telephoneService.getTelephoneBytelephoneno(telephoneNo);
		return telephone;
	}
	
	@GetMapping("/bymobileno/{mobileNo}")
	public Telephone getTelephoneBymobileno(@PathVariable String mobileNo) {	
		Telephone telephone = telephoneService.getTelephoneBymobileno(mobileNo);
		return telephone;
	}
	
	/*
	 * @GetMapping("/moviesall") public Movie getall() { Movie movie =
	 * movieService.getall(); return movie; }
	 * 
	 * @GetMapping("/remove/{movieId}") public Movie removeMovieById(@PathVariable
	 * int movieId) { Movie movie = movieService.removeMovieById(movieId); return
	 * movie; }
	 */
	

	
	  @GetMapping("{telephoneId}") public Telephone getTelephoneById(@PathVariable int telephoneId)
	  { Telephone telephone = telephoneService.getTelephoneById(telephoneId); if(telephone==null) throw new
	  TelephoneNotFoundException("TELEPHONE ID IS INVALID"); return telephone; }
	 

}
