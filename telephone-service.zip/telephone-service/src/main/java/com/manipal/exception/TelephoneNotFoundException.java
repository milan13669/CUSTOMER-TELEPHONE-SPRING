package com.manipal.exception;

public class TelephoneNotFoundException extends RuntimeException {

	public TelephoneNotFoundException(String message)
    {
   	 super(message);
    }
}
