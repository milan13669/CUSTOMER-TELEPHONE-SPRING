package com.manipal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="telephone")
public class Telephone {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="telephone_id")
	private int telephoneId;
	@Column(name = "telephone_no")
	private String telephoneNo;
	@Column(name = "mobile_no")
	private String mobileNo;
	
	public Telephone() { }

	public Telephone(int telephoneId, String telephoneNo, String mobileNo) {
		super();
		this.telephoneId = telephoneId;
		this.telephoneNo = telephoneNo;
		this.mobileNo = mobileNo;
	}

	public int getTelephoneId() {
		return telephoneId;
	}

	public void setTelephoneId(int telephoneId) {
		this.telephoneId = telephoneId;
	}

	public String getTelephoneNo() {
		return telephoneNo;
	}

	public void setTelephoneNo(String telephoneNo) {
		this.telephoneNo = telephoneNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Override
	public String toString() {
		return "Telephone [telephoneId=" + telephoneId + ", telephoneNo=" + telephoneNo + ", mobileNo=" + mobileNo
				+ "]";
	}
	
	

}
