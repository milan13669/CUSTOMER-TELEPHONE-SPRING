package com.manipal.service;

import com.manipal.model.Telephone;

public interface ITelephoneService {
	
	public Telephone getTelephoneById(int telephoneId);
	void addOrUpdateTelephone(Telephone telephone);
	public Telephone getTelephoneBytelephoneno(String telephoneNo);
	public Telephone getTelephoneBymobileno(String mobileNo);
	

}
