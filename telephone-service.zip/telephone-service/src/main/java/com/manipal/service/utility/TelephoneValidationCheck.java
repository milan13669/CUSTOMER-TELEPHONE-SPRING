package com.manipal.service.utility;

import com.manipal.model.Telephone;

public class TelephoneValidationCheck {
	public static boolean validateTelephone(Telephone telephone) {
		  
	    return true;
  }

}
