package com.manipal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manipal.model.Telephone;
import com.manipal.repository.ITelephoneRepository;
import com.manipal.service.utility.TelephoneValidationCheck;

@Service
public class TelephoneService implements ITelephoneService {
	@Autowired
	private ITelephoneRepository repository;

	public void updateTelephone(Telephone telephone) {
		repository.save(telephone);
	}

	@Override
	public void addOrUpdateTelephone(Telephone telephone) {

		repository.save(telephone);

		//		String validationStatus = "Not Validated";
		//		if(MovieValidationCheck.validateMovie(movie)) {
		//		repository.save(movie);
		//		validationStatus = "Validated";
		//		}
		//		else
		//		{
		//			validationStatus = "Not Validated";
		//		}
		//		
		//		return validationStatus;

	}

	@Override 
	public Telephone getTelephoneById(int telephoneId) { 
		return repository.findById(telephoneId).orElse(null); 
	}

	@Override
	public Telephone getTelephoneBytelephoneno(String telephoneNo) {
		// TODO Auto-generated method stub
		return repository.findBytelephoneNo(telephoneNo).orElse(null);
	}

	@Override
	public Telephone getTelephoneBymobileno(String mobileNo) {
		// TODO Auto-generated method stub
		return repository.findBymobileNo(mobileNo).orElse(null);
	}

}
