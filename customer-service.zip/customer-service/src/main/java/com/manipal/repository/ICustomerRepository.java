package com.manipal.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.manipal.model.Customer;

@Repository
public interface ICustomerRepository extends JpaRepository<Customer, Integer> {

	Optional<Customer> findBycustomerFirstName(String customerFirstName);
	Optional<Customer> findBycustomerLastName(String customerLastName);
}
