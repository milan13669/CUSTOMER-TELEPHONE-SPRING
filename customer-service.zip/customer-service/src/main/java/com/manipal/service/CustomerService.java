package com.manipal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manipal.model.Customer;
import com.manipal.repository.ICustomerRepository;
import com.manipal.service.utility.CustomerValidationCheck;

@Service
public class CustomerService implements ICustomerService {
	@Autowired
	private ICustomerRepository repository;

	public void updateCustomer(Customer customer) {
		repository.save(customer);
	}

	@Override
	public void addOrUpdateCustomer(Customer customer) {

		repository.save(customer);

		//		String validationStatus = "Not Validated";
		//		if(MovieValidationCheck.validateMovie(movie)) {
		//		repository.save(movie);
		//		validationStatus = "Validated";
		//		}
		//		else
		//		{
		//			validationStatus = "Not Validated";
		//		}
		//		
		//		return validationStatus;

	}

	@Override 
	public Customer getCustomerById(int customerId) { 
		return repository.findById(customerId).orElse(null); 
	}

	@Override
	public Customer getCustomerBycustomerfirstname(String customerFirstName) {
		// TODO Auto-generated method stub
		return repository.findBycustomerFirstName(customerFirstName).orElse(null);
	}

	@Override
	public Customer getCustomerBycustomerlastname(String customerLastName) {
		// TODO Auto-generated method stub
		return repository.findBycustomerLastName(customerLastName).orElse(null);
	}

}
