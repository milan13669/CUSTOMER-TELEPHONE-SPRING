package com.manipal.service;

import com.manipal.model.Customer;

public interface ICustomerService {
	
	public Customer getCustomerById(int customerId);
	void addOrUpdateCustomer(Customer customer);
	public Customer getCustomerBycustomerfirstname(String customerFirstName);
	public Customer getCustomerBycustomerlastname(String customerLastName);
	

}
