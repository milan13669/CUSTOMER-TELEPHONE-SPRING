package com.manipal.service.utility;

import com.manipal.model.Customer;

public class CustomerValidationCheck {
	public static boolean validateTelephone(Customer customer) {
		  
	    return true;
  }

}
